Workwise is a HTML5 & CSS3 responsive template created for Freelancer and Social Networking Plateform but also can be used for generalised website. Workwise will be a subtle and smart choice for user post project and receive competitive bids from freelancers within minutes. Our reputation system will make it easy to find the perfect freelancer for your job. It's the simplest and safest way to get work done online. It is a fully responsive, feature rich and beautifully designed to host a website or create online identity. We have created html pages and components for this template and much more in future. It supports bootstrap framework and intergrated font awesome icon set so easy to customise and develop your own styles. Workwise is a retina ready so it works nicely on smartphones, tablet PCs and desktops. Easily customisable, 24/7 support time.


Features
-  Html files included
-  01 Homepages unique
-  03 Profile layouts style
-  03 Signup layouts style
-  01 Messages layouts style
-  02 Post layout style
-  Creative and unique design
-  Base on Bootstrap 3
-  Designed on 1170px Grid system
-  Easy & customizable PSD files
-  Pixel Perfect
-  Excellent Responsive
-  Free Google Fonts
-  Extended documentation�
-  Free Png Based Icons
-  Payment sent and withdraw options
-  Chat on homepage
-  Forum page�
-  Account setting pages


Icon8 : https://icons8.com/icon/new-icons/ios7



Fonts
Source Sans Pro: https://fonts.google.com/specimen/Source+Sans+Pro 



IMPORTANT!!! All Images are from different resources and they are not included to PSD files.


Pixel Dimensions: 1600x2640

Tags: Freelancer, social media, social networking, work, red, messages, white, earning, psd template, pixel perfect, timeline. portfolio,profile, agency, studio, wordpress, php, mobile apps, icons, vectors.