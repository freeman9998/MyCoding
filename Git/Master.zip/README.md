## Git tuto

The source code is as follows

```c
#include <stdio.h>

  int main(void) {
    printf("Git tuto");
    return 0;
  }
```

The link can be created as follows

[link name](site url)

unordered list can create as follows

*Git tuto
  *Git clone
  *Git commit
    *git commit step1

misquotation can be created as follows

> 'Git world' -dongdong-

can make table as follows

name|address|age|number
---|---|---|---|
kimjimin|dongdong|21|01052640000
donghyeon|jimin|24|01037850000

emphasis can create as follows

**chicken** ~~delicious~~

